<!DOCTYPE html>
<html>
<head>
 <title>{{ env('APP_NAME') }}</title>
</head>
<body>
 <h1>الاسم : {{ $name }}</h1>
 <h1>الايميل : {{ $email }}</h1>
 <p>{{ $body }}</p>
 
</body>
</html>