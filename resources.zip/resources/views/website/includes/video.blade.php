<div class="video-area-box">
    <div class="container">
        <div class="video-view-content" data-aos="fade-up" data-aos-delay="80" data-aos-duration="800" data-aos-once="true">
            <div class="video-image">
                <img src="{{ asset('assets/images/video/video.jpg') }}" alt="image">
            </div>

            <a href="{{ $about->video_url }}" class="video-btn popup-youtube">
                <i class="ri-play-mini-fill"></i>
            </a>
        </div>
    </div>
</div>